THE SOURCE by bioMECI
Linux Manual Installation
Version 0.9.0

Tested on Ubuntu 26.04.1 LTS, x86_64.

STANDALONE
----------

The Standalone application is located in:

    Standalone/

Keep these two files together:

    THE SOURCE
    liblsl.so.2

Run THE SOURCE with:

    ./THE SOURCE

If required, make it executable with:

    chmod +x "THE SOURCE"


VST3
----

The VST3 plugin is located in:

    VST3/THE SOURCE.vst3

For a per-user installation, copy the complete
THE SOURCE.vst3 directory to:

    ~/.vst3/

For example:

    mkdir -p ~/.vst3
    cp -r "VST3/THE SOURCE.vst3" ~/.vst3/

Do not copy individual files out of the VST3 bundle.


LINUX COMPATIBILITY
-------------------

THE SOURCE has been tested on Ubuntu 26.04.1 LTS
(64-bit x86_64).

Other Linux distributions may work but have not
been formally tested or supported.
